<?php return array('version' => '056c1ba17cd2f0c46f27');
