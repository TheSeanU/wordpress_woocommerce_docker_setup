<?php return array('version' => 'bfe6d8c291361a2d0b2c');
