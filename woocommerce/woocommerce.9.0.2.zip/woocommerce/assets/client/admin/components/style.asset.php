<?php return array('version' => '436fe1acf1d054f952c0');
