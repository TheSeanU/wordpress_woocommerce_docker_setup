<?php return array('dependencies' => array('wc-customer-effort-score'), 'version' => 'f485039408af08300aff');
