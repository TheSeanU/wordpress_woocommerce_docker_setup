<?php return array('dependencies' => array('wc-components', 'wc-store-data', 'wc-tracks', 'wp-element', 'wp-i18n'), 'version' => '469f4067a70c0136e997');
