<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks'), 'version' => '27f6c310d71e883d9f21');
