<?php return array('dependencies' => array('moment'), 'version' => '39d5ef2cb8ea94519ed1');
