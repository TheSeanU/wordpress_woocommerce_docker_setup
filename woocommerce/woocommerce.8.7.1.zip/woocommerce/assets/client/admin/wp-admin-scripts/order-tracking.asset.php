<?php return array('dependencies' => array('wc-customer-effort-score'), 'version' => 'ff78a37c095df94767ef');
