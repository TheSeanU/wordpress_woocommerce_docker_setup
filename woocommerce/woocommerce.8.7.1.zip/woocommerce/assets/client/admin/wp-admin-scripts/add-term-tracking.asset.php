<?php return array('dependencies' => array('wc-tracks'), 'version' => 'eca3f91deeadbc526aac');
