<?php return array('dependencies' => array('wc-customer-effort-score', 'wc-tracks'), 'version' => '110aaff27bfea88fa07d');
